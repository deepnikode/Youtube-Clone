export interface CommentDto {
  commentText: string,
  authorId: string
}
