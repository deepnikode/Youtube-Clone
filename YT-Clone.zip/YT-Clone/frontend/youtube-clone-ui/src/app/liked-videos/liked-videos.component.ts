import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liked-videos',
  templateUrl: './liked-videos.component.html',
  styleUrls: ['./liked-videos.component.css']
})
export class LikedVideosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
