export interface UploadVideoResponse{
  videoId: string,
  videoUrl: string;
}
