package com.programming.techie.youtubeclone.model;

public enum VideoStatus {
    PUBLIC, PRIVATE, UNLISTED
}
